#include <stdio.h>
#include <stdlib.h>
#include <time.h>

    
int main(void) {
	srand(time(NULL));
	int rowsums[10] = {0};
	int colsums[10] = {0};
	int array[10][10];
	for (int i=0; i < 10; i++) { 
		for (int j=0; j < 10; j++) { 
			array[i][j] = rand() % 11;
			printf("%d\t", array[i][j]);
		}
		printf("\n");
	}
	printf("\n");
	for (int i=0; i < 10; i++) { 
		for (int j=0; j < 10; j++) {
			rowsums[i] += array[i][j];
			colsums[j] += array[i][j];
		}
	}
	for (int i=0; i < 10; i++) {
		printf("%d ", rowsums[i]);
	}
	printf("\n");
	for (int i=0; i < 10; i++) {
		printf("%d ", colsums[i]);
	}
	printf("\n");
	system("pause");
}
